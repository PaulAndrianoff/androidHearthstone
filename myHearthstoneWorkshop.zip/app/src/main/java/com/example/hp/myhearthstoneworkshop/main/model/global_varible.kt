package com.example.hp.myhearthstoneworkshop.main.model

import com.example.hp.myhearthstoneworkshop.R

val imageArray = arrayListOf(R.drawable.chaman,
        R.drawable.demon,
        R.drawable.druid,
        R.drawable.hunter,
        R.drawable.mage,
        R.drawable.priest,
        R.drawable.rogue,
        R.drawable.warrior)