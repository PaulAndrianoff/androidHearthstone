package com.example.hp.myhearthstoneworkshop.main.model

//import com.fasterxml.jackson.annotation.JsonIgnoreProperties
//
//@JsonIgnoreProperties(ignoreUnknown = true)
class Card constructor(name:String = "", img:String, text:String="", cardSet:String, type:String, attack:Int, health:Int, cost:Int){
    val name:String = name
    val img:String = img
    val text:String = text
    val cardSet:String = cardSet
    val type:String = type
    val attack:Int = attack
    val health:Int = health
    val cost:Int = cost
}